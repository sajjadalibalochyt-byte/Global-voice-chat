# Global Chat + Live Voice Room (Render-ready)

## What is this?
A minimal combined app:
- Global text chat (Socket.io)
- 1-to-1 Live Voice Rooms (WebRTC signaling via Socket.io)
- Simple matching queue with "Next" button

## How to deploy on Render
1. Create an account on https://render.com
2. Create a new **Web Service**
3. Choose "Deploy from ZIP" and upload this project ZIP
4. Set:
   - Environment: Node
   - Build Command: `npm install`
   - Start Command: `npm start`
5. Deploy — Render will give you an HTTPS URL.

## Notes
- For public deployment, STUN is used. If users are behind restrictive NATs, add a TURN server.
- This project keeps both frontend and backend together for simplicity.