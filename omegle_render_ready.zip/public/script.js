const socket = io();
const nameInput = document.getElementById('nameInput');
const joinGlobalBtn = document.getElementById('joinGlobalBtn');
const globalMessages = document.getElementById('globalMessages');
const globalInput = document.getElementById('globalInput');
const sendGlobal = document.getElementById('sendGlobal');

const voiceJoin = document.getElementById('voiceJoin');
const voiceNext = document.getElementById('voiceNext');
const voiceStatus = document.getElementById('voiceStatus');
const localAudio = document.getElementById('localAudio');
const remoteAudio = document.getElementById('remoteAudio');

let localStream = null;
let pc = null;
let currentPartner = null;
let isInitiator = false;

// GLOBAL CHAT
joinGlobalBtn.addEventListener('click', () => {
  const name = nameInput.value || 'Anonymous';
  socket.emit('join-global', { name });
  appendSystem('You joined the global chat as ' + name);
  joinGlobalBtn.disabled = true;
});

sendGlobal.addEventListener('click', () => {
  const text = globalInput.value.trim();
  if (!text) return;
  socket.emit('global-message', { text });
  appendMessage({ id: socket.id, name: nameInput.value||'You', text }, true);
  globalInput.value = '';
});

socket.on('global-message', (msg) => {
  appendMessage(msg, msg.id === socket.id);
});
socket.on('global-system', ({ message }) => {
  appendSystem(message);
});

function appendMessage(msg, mine=false) {
  const div = document.createElement('div');
  div.className = 'message ' + (mine ? 'me' : 'other');
  div.innerHTML = `<strong>${mine ? 'You' : (msg.name||'Anon')}</strong>: ${escapeHtml(msg.text)}`;
  globalMessages.appendChild(div);
  globalMessages.scrollTop = globalMessages.scrollHeight;
}
function appendSystem(text) {
  const div = document.createElement('div');
  div.className = 'message';
  div.style.background = '#fff3cd';
  div.textContent = text;
  globalMessages.appendChild(div);
  globalMessages.scrollTop = globalMessages.scrollHeight;
}
function escapeHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// VOICE ROOM (WebRTC via Socket signaling)
const pcConfig = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

voiceJoin.addEventListener('click', async () => {
  voiceJoin.disabled = true;
  voiceStatus.textContent = 'Joining queue…';
  await ensureLocalStream();
  socket.emit('register-voice');
});

voiceNext.addEventListener('click', () => {
  socket.emit('voice-next');
  voiceNext.disabled = true;
  voiceStatus.textContent = 'Finding next…';
  cleanupCall();
});

socket.on('voice-queued', () => {
  voiceStatus.textContent = 'In queue — waiting for a partner…';
});

socket.on('voice-matched', async ({ partnerId, roomId, initiator }) => {
  currentPartner = partnerId;
  isInitiator = initiator;
  voiceStatus.textContent = 'Matched! Connecting…';
  voiceNext.disabled = false;
  await startPeerConnection();
  if (isInitiator) {
    // create offer
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    socket.emit('webrtc-offer', { to: partnerId, sdp: offer });
  }
});

socket.on('partner-left', () => {
  appendSystem('Your partner left the voice room.');
  voiceStatus.textContent = 'Partner left. You can requeue (Next will requeue).';
  cleanupCall();
  voiceNext.disabled = false;
});

socket.on('webrtc-offer', async ({ from, sdp }) => {
  currentPartner = from;
  isInitiator = false;
  await startPeerConnection();
  await pc.setRemoteDescription(new RTCSessionDescription(sdp));
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  socket.emit('webrtc-answer', { to: from, sdp: answer });
});

socket.on('webrtc-answer', async ({ from, sdp }) => {
  await pc.setRemoteDescription(new RTCSessionDescription(sdp));
});

socket.on('webrtc-ice', async ({ from, candidate }) => {
  try {
    await pc.addIceCandidate(candidate);
  } catch (e) {
    console.warn('ICE add failed', e);
  }
});

async function ensureLocalStream() {
  if (!localStream) {
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      localAudio.srcObject = localStream;
    } catch (e) {
      alert('Microphone access required for voice rooms.');
      throw e;
    }
  }
}

async function startPeerConnection() {
  if (pc) return;
  pc = new RTCPeerConnection(pcConfig);
  // add local tracks
  localStream.getTracks().forEach(t => pc.addTrack(t, localStream));

  pc.ontrack = (ev) => {
    // remote audio
    remoteAudio.srcObject = ev.streams[0];
  };
  pc.onicecandidate = (ev) => {
    if (ev.candidate && currentPartner) {
      socket.emit('webrtc-ice', { to: currentPartner, candidate: ev.candidate });
    }
  };
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === 'connected') {
      voiceStatus.textContent = 'Connected!';
    } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
      voiceStatus.textContent = 'Disconnected';
    }
  };
}

function cleanupCall() {
  if (pc) {
    try { pc.close(); } catch(e){}
    pc = null;
  }
  currentPartner = null;
  remoteAudio.srcObject = null;
}

// basic UX: allow pressing Enter to send message
globalInput.addEventListener('keydown', (e)=>{ if(e.key==='Enter') sendGlobal.click(); });