import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// Simple global chat room
io.on('connection', (socket) => {
  console.log('Socket connected:', socket.id);

  // GLOBAL CHAT
  socket.on('join-global', ({ name }) => {
    socket.join('global-room');
    socket.data.name = name || 'Anonymous';
    io.to('global-room').emit('global-system', { message: `${socket.data.name} joined the global chat.` });
  });

  socket.on('global-message', ({ text }) => {
    const payload = { id: socket.id, name: socket.data.name || 'Anonymous', text, ts: Date.now() };
    io.to('global-room').emit('global-message', payload);
  });

  // VOICE MATCHING (1-to-1)
  // simple waiting queue for voice pairing
  if (!global.waitingVoice) global.waitingVoice = null;

  socket.on('register-voice', () => {
    // if someone waiting and not the same socket, match them
    if (global.waitingVoice && global.waitingVoice.socketId !== socket.id) {
      const a = global.waitingVoice;
      const b = { socketId: socket.id };
      const roomId = uuidv4();

      // tell both about match and who is initiator
      io.to(a.socketId).emit('voice-matched', { partnerId: b.socketId, roomId, initiator: true });
      io.to(b.socketId).emit('voice-matched', { partnerId: a.socketId, roomId, initiator: false });

      // attach partner references
      io.sockets.sockets.get(a.socketId).data.partner = b.socketId;
      io.sockets.sockets.get(b.socketId).data.partner = a.socketId;

      global.waitingVoice = null;
    } else {
      // put this socket in waiting queue
      global.waitingVoice = { socketId: socket.id };
      socket.emit('voice-queued');
    }
  });

  // "Next" action -> leave current partner and re-register
  socket.on('voice-next', () => {
    const partner = socket.data.partner;
    if (partner) {
      io.to(partner).emit('partner-left');
      const s = io.sockets.sockets.get(partner);
      if (s) s.data.partner = null;
      socket.data.partner = null;
    }
    // register again
    socket.emit('requeue');
    socket.emit('voice-queued');
    if (!global.waitingVoice) global.waitingVoice = { socketId: socket.id };
    else {
      // immediate match
      const a = global.waitingVoice;
      const b = { socketId: socket.id };
      const roomId = uuidv4();
      io.to(a.socketId).emit('voice-matched', { partnerId: b.socketId, roomId, initiator: true });
      io.to(b.socketId).emit('voice-matched', { partnerId: a.socketId, roomId, initiator: false });
      io.sockets.sockets.get(a.socketId).data.partner = b.socketId;
      io.sockets.sockets.get(b.socketId).data.partner = a.socketId;
      global.waitingVoice = null;
    }
  });

  // Signaling messages for WebRTC
  socket.on('webrtc-offer', ({ to, sdp }) => {
    io.to(to).emit('webrtc-offer', { from: socket.id, sdp });
  });
  socket.on('webrtc-answer', ({ to, sdp }) => {
    io.to(to).emit('webrtc-answer', { from: socket.id, sdp });
  });
  socket.on('webrtc-ice', ({ to, candidate }) => {
    io.to(to).emit('webrtc-ice', { from: socket.id, candidate });
  });

  socket.on('disconnect', () => {
    console.log('Socket disconnected:', socket.id);
    // handle waiting removal
    if (global.waitingVoice && global.waitingVoice.socketId === socket.id) global.waitingVoice = null;
    const partner = socket.data.partner;
    if (partner) {
      io.to(partner).emit('partner-left');
      const s = io.sockets.sockets.get(partner);
      if (s) s.data.partner = null;
    }
    io.to('global-room').emit('global-system', { message: `${socket.data.name || 'A user'} left.` });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Server running on port', PORT));